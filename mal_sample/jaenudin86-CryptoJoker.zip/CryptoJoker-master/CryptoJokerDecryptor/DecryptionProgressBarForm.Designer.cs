﻿namespace CryptoJokerDecryptor
{
    partial class DecryptionProgressBarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DecryptionProcessProgressBar = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // DecryptionProcessProgressBar
            // 
            this.DecryptionProcessProgressBar.Location = new System.Drawing.Point(12, 16);
            this.DecryptionProcessProgressBar.Name = "DecryptionProcessProgressBar";
            this.DecryptionProcessProgressBar.Size = new System.Drawing.Size(472, 37);
            this.DecryptionProcessProgressBar.TabIndex = 0;
            // 
            // DecryptionProgressBarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 73);
            this.ControlBox = false;
            this.Controls.Add(this.DecryptionProcessProgressBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DecryptionProgressBarForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Please wait ...";
            this.Load += new System.EventHandler(this.DecryptionProgressBarForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ProgressBar DecryptionProcessProgressBar;
    }
}